"""
Shared pytest fixtures: generates random synthetic datasets,
cleans up model/metrics artifacts between test sessions.
"""
import os
import shutil
import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api import app
from src.config import MODELS_DIR, METRICS_DIR, RAW_DATA_DIR, PROCESSED_DATA_DIR


@pytest.fixture(scope="session")
def client():
    return TestClient(app)


@pytest.fixture(scope="function")
def random_training_csv(tmp_path):
    """Generate a random CSV dataset for training with reproducible-ish randomness."""
    np.random.seed()  # true randomness per test run
    n_rows = np.random.randint(50, 200)

    df = pd.DataFrame({
        "feature_1": np.random.uniform(0, 100, n_rows),
        "feature_2": np.random.uniform(-50, 50, n_rows),
        "feature_3": np.random.randint(1, 10, n_rows).astype(float),
    })
    # Synthetic target with noise, loosely related to features
    df["target"] = (
        df["feature_1"] * np.random.uniform(0.5, 2.0)
        + df["feature_2"] * np.random.uniform(-1.5, 1.5)
        + df["feature_3"] * np.random.uniform(1, 5)
        + np.random.normal(0, 5, n_rows)
    )

    file_path = tmp_path / f"train_{np.random.randint(1000,9999)}.csv"
    df.to_csv(file_path, index=False)
    return str(file_path)


@pytest.fixture(scope="session", autouse=True)
def cleanup_artifacts():
    """Clean generated artifacts after full test session."""
    yield
    # Optional cleanup — comment out if you want to inspect artifacts after CI run
    for d in [RAW_DATA_DIR, PROCESSED_DATA_DIR]:
        for f in os.listdir(d):
            if f != ".gitkeep":
                os.remove(os.path.join(d, f))
tests/test_train_predict.py
"""
Unit tests for training and prediction logic using randomly generated data.
"""
import random
import numpy as np
import pandas as pd
import pytest

from src.train import train_model
from src.predict import predict_single, get_required_features
from src.data_handler import validate_training_data, DataValidationError


def _generate_random_dataframe(n_rows=None):
    n_rows = n_rows or random.randint(30, 150)
    df = pd.DataFrame({
        "feature_1": np.random.uniform(0, 100, n_rows),
        "feature_2": np.random.uniform(-50, 50, n_rows),
        "feature_3": np.random.randint(1, 10, n_rows).astype(float),
    })
    df["target"] = (
        df["feature_1"] * 1.2 + df["feature_2"] * -0.8 + df["feature_3"] * 3
        + np.random.normal(0, 3, n_rows)
    )
    return df


def test_train_model_fresh_run():
    df = _generate_random_dataframe()
    result = train_model(df)

    assert "metrics" in result
    assert "r2_score" in result["metrics"]
    assert "mae" in result["metrics"]
    assert "mse" in result["metrics"]
    assert result["rows_used"] == df.shape[0]


def test_train_model_incremental_run():
    # First training
    df1 = _generate_random_dataframe()
    result1 = train_model(df1)
    version_1 = result1["version"]

    # Second (incremental) training with new random data only
    df2 = _generate_random_dataframe()
    result2 = train_model(df2)

    assert result2["is_incremental"] is True
    assert result2["version"] == version_1 + 1
    assert result2["rows_used"] == df2.shape[0]


def test_predict_with_random_values():
    df = _generate_random_dataframe()
    train_model(df)

    features = get_required_features()
    random_input = {f: round(random.uniform(-100, 100), 3) for f in features}

    prediction = predict_single(random_input)
    assert isinstance(prediction, float)


def test_predict_missing_feature_raises():
    df = _generate_random_dataframe()
    train_model(df)

    features = get_required_features()
    incomplete_input = {features[0]: random.uniform(0, 10)}  # missing others

    with pytest.raises(ValueError):
        predict_single(incomplete_input)


def test_validate_training_data_rejects_missing_target():
    df = _generate_random_dataframe().drop(columns=["target"])
    with pytest.raises(DataValidationError):
        validate_training_data(df)


def test_validate_training_data_rejects_too_few_rows():
    df = _generate_random_dataframe(n_rows=3)
    with pytest.raises(DataValidationError):
        validate_training_data(df)


@pytest.mark.parametrize("trial", range(3))
def test_multiple_random_training_cycles(trial):
    """Run several random incremental training cycles to ensure stability."""
    df = _generate_random_dataframe(n_rows=random.randint(40, 100))
    result = train_model(df)
    assert result["metrics"]["mse"] >= 0
    assert -1.5 <= result["metrics"]["r2_score"] <= 1.0
tests/test_api.py
"""
API endpoint tests using FastAPI's TestClient, with randomly generated data.
"""
import io
import random
import numpy as np
import pandas as pd


def _random_csv_bytes(n_rows=None):
    n_rows = n_rows or random.randint(40, 120)
    df = pd.DataFrame({
        "feature_1": np.random.uniform(0, 100, n_rows),
        "feature_2": np.random.uniform(-50, 50, n_rows),
        "feature_3": np.random.randint(1, 10, n_rows).astype(float),
    })
    df["target"] = df["feature_1"] * 1.5 + df["feature_2"] * -0.5 + np.random.normal(0, 4, n_rows)

    buffer = io.BytesIO()
    df.to_csv(buffer, index=False)
    buffer.seek(0)
    return buffer


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_train_endpoint_success(client):
    csv_bytes = _random_csv_bytes()
    response = client.post(
        "/train",
        files={"file": ("random_train.csv", csv_bytes, "text/csv")},
    )
    assert response.status_code == 200
    data = response.json()
    assert "result" in data
    assert "metrics" in data["result"]


def test_train_endpoint_rejects_non_csv(client):
    response = client.post(
        "/train",
        files={"file": ("not_csv.txt", io.BytesIO(b"hello"), "text/plain")},
    )
    assert response.status_code == 400


def test_schema_endpoint_after_training(client):
    csv_bytes = _random_csv_bytes()
    client.post("/train", files={"file": ("train.csv", csv_bytes, "text/csv")})

    response = client.get("/model/schema")
    assert response.status_code == 200
    assert "required_features" in response.json()


def test_predict_endpoint_with_random_values(client):
    # Ensure model exists
    csv_bytes = _random_csv_bytes()
    client.post("/train", files={"file": ("train.csv", csv_bytes, "text/csv")})

    schema_resp = client.get("/model/schema")
    features = schema_resp.json()["required_features"]

    random_payload = {f: round(random.uniform(-100, 100), 2) for f in features}
    response = client.post("/predict", json={"features": random_payload})

    assert response.status_code == 200
    assert isinstance(response.json()["prediction"], float)


def test_predict_endpoint_missing_feature_returns_422(client):
    csv_bytes = _random_csv_bytes()
    client.post("/train", files={"file": ("train.csv", csv_bytes, "text/csv")})

    response = client.post("/predict", json={"features": {"nonexistent_feature": 1.0}})
    assert response.status_code == 422


def test_metrics_history_endpoint(client):
    csv_bytes = _random_csv_bytes()
    client.post("/train", files={"file": ("train.csv", csv_bytes, "text/csv")})

    response = client.get("/metrics/history")
    assert response.status_code == 200
    assert isinstance(response.json()["history"], list)
    assert len(response.json()["history"]) >= 1


def test_metrics_latest_endpoint(client):
    csv_bytes = _random_csv_bytes()
    client.post("/train", files={"file": ("train.csv", csv_bytes, "text/csv")})

    response = client.get("/metrics/latest")
    assert response.status_code == 200
    body = response.json()
    assert "r2_score" in body
    assert "mae" in body
    assert "mse" in body